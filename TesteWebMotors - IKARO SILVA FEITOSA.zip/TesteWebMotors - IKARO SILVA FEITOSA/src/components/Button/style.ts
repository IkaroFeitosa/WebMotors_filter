
import styled, { css } from 'styled-components'


export const Container = styled.button<{isTransparente?:boolean, variant?:string}>`
    background-color: #d70b31;
    padding: 5px 40px;
    border: solid 1px #cb0f32;
    font-weight: bold;
    font-size: medium;
    color: white;
    cursor: pointer;

    ${props => props.isTransparente && css`
        background-color: transparent;
        color: darkgray;
        font-weight: normal;
        font-size: initial;
        border: 0px;
    `}  
    ${props => props.variant && css`
        background-color: transparent;
        color: #cb0f32;
        font-weight: bold;
        font-size: initial;
        border: 0px;
        padding: 5px 0px;
    `}   
`