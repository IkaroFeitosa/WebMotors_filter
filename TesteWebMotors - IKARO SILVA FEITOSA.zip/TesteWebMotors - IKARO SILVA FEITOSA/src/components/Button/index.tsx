import { ReactNode } from "react"
import { Container } from "./style"
interface IButton {
    children?: ReactNode;
    isTransparente?: boolean
    variant?: 'simples'
    content?: string
}
export const Button = ({children,isTransparente, variant,content}:IButton) => {
    if(variant === 'simples'){
        return (
            <Container variant={variant}>
                {content}
            </Container>
        )
    }
    return (
        <Container isTransparente={isTransparente}>
            {children}
        </Container>
    )
}