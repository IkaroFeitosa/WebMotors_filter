
import styled from 'styled-components'


export const App = styled.div `
    background-color: #f3f5f8;
    max-width: 933px;
    height: 312px;
    margin: 0 auto;
    flex-direction: column;
    display: flex;
    padding: 15px 10px;
`
export const Logo = styled.img`
    max-width: 200px;
    pointer-events: none;
`

