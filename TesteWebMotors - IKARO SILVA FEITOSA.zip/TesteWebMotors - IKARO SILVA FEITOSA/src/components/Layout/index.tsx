import { ReactNode } from "react"
import { App } from "./style"

export interface ILayout {
    children?: ReactNode
  }

export const Layout = ({children}:ILayout) => {

    return(
        <App>
            {children}
        </App>
    )
}