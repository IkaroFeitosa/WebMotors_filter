
import styled, { css } from 'styled-components'

export const ContainerMenu = styled.div `
    width: 100%;
    display: flex;
    
    margin-top: 20px;
    align-items: center;

`
export const Button = styled.div<{active?:boolean}>`
    display: flex;
    position: relative;
    align-items: flex-end;
    padding: 5px 10px;
    & > span.label {
        margin-left: 5px;
        color: darkgray;
        &> h6 {
            font-weight: 400;
            margin: 0;
            
        }
        &> h3 {
            margin: 0;
            font-weight: 500;
        }
    }
    ${props => props.active && css`
        &> span.label > h3 {
            color: #f3123c;
        }
        border-bottom: #f3123c 3px solid;
    `}
    
    cursor: pointer;
`
export const ButtonRight = styled.div`
    padding: 5px 10px;
    background-color: transparent;
    border: #f39d12 3px solid;
    color: #f39d12;
    font-weight: bold;
    height: fit-content;
    cursor: pointer;
    margin-left: auto;
    
`
