import { Button, ButtonRight, ContainerMenu } from "./style"
import {BiCar} from 'react-icons/bi'
import {FaMotorcycle} from 'react-icons/fa'
import { useState } from "react"

export const Menu = () => {
   const [active,setActive] = useState(0)
    return (
        <ContainerMenu >
            <Button active={active === 0} onClick={()=>setActive(0)}>
                <BiCar size='24px' color={active === 0 ? "#f3123c":"darkgrey"} />
                <span className="label">
                    <h6>COMPRAR</h6>
                    <h3>CARROS</h3>
                </span>

            </Button>
            <Button active={active === 1} onClick={()=>setActive(1)}>
                <FaMotorcycle size='24px' color={active === 1 ? "#f3123c":"darkgrey"}  />
                <span className="label">
                    <h6>COMPRAR</h6>
                    <h3>MOTOS</h3>
                </span>

            </Button>
            <ButtonRight>
                Vender meu carro
            </ButtonRight>
        </ContainerMenu>
    )
}