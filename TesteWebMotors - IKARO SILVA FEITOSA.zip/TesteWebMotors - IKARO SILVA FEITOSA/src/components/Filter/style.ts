
import styled, { css } from 'styled-components'


export const Container = styled.div `
    background-color: #fff;
    align-self: stretch;
    padding: 20px 40px;
    flex: 2;
`
export const Row = styled.div `
    margin-bottom: 10px;
    display: flex;
    gap: 5px;
`
export const Col = styled.div<{flex?:number}>`
    display: flex;
    & > div:first-child {
        border-top-left-radius: 3px;
        border-bottom-left-radius: 3px;
    }
    & > div:last-child {
        border-top-right-radius: 3px;
        border-bottom-right-radius: 3px;
    }
    
   ${props => props.flex && css`
     flex: ${props.flex};
   `}
`

