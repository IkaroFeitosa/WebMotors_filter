import { useEffect, useState } from "react"
import { getMaker, getModel } from "../../api"
import { Button } from "../Button"
import { Input } from "../Input"
import { Col, Container, Row } from "./style"

export const Filter = () => {
    const [marcas,setMarcas] = useState<any>()
    const [marca,setMarca] = useState<number>()
    const [modelos,setModelos] = useState<any>()
    const [modelo,setModelo] = useState<number>()

    useEffect(()=> {
        getMaker().then(e => {
            if(e.status === 200){
                setMarcas(e.data)
            }
            else{
                setMarcas([])
            }
        }).catch(Error => {
            console.log('Erro Marca = ', Error)
            setMarcas([{ID:1,Name:'Chevrolet'},{ID:2,Name:'Honda'},{ID:3,Name:'Hyundai'}])
        })
    },[])
    useEffect(()=> {
        console.log(marca)
            getModel(marca || 1).then(e => {
                if(e.status === 200){
                    setModelos(e.data)
                }
                else{
                    setModelos([])
                }
            }).catch(Error => {
                console.log('Erro Model = ', Error)
                const mockModel = [{MakeID:1,Name:'Onix'},{MakeID:2,Name:'Civic'},{MakeID:3,Name:'Tucson'}];
                if(marca)
                    setModelos(mockModel.filter((m:any)=>m.MakeID === marca))
                else
                    setModelos(mockModel)
                
            })
    },[marca])
    return (
        <Container>
            <Row>
                <Col>
                    <label><input type='checkbox' /> Novos</label>
                </Col>
                <Col>
                    <label><input type='checkbox' /> Usados</label>
                </Col>
            </Row>
            <Row>
                <Col flex={2}><Input type="Location" /><Input type="Raio" /></Col>
                <Col flex={1}><Input type="Marca" options={marcas} setValue={setMarca}/></Col>
                <Col flex={1}><Input type="Modelo" options={modelos}/></Col>
            </Row>
            <Row>
                <Col flex={1}><Input type="Ano" /></Col>
                <Col flex={1}><Input type="Preco" /></Col>
                <Col flex={2}><Input type="Versao" /></Col>
            </Row>

            <Row style={{marginTop:'20px'}}>
                <Col><Button variant="simples" content="> Limpar filtros" /></Col>
                <Col style={{marginLeft:'auto'}}><Button isTransparente>Limpar filtros</Button></Col>
                <Col ><Button>VER OFERTAS</Button></Col>
            </Row>
        </Container>
    )
}