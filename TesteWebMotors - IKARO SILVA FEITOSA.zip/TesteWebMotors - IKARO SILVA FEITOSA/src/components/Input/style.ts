
import styled, { css } from 'styled-components'


export const Container = styled.div<{flex?:number}> `
    border: solid 1px #ccc;
    display: flex;
    padding: 5px;
    align-items: center;
    color: gray;
    font-weight: 500;
    &> select,input {
        border: 0;
       
        font-weight: bold;
        padding-left: 5px;
        color: #403f3f;
        width: 100%;
        &#Location {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
        }
        min-height: 20px;

    }
    ${props => props.flex && css`
        flex: ${props.flex};
    `}
`
export const BtnClose = styled.div `
    display: inline-flex;
    margin-left: 5px;
    cursor: pointer;
`

