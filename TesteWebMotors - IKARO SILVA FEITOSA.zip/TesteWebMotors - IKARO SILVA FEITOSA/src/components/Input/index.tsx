import { useState } from "react"
import { FaTimesCircle } from "react-icons/fa"
import { IoLocationOutline } from "react-icons/io5"
import { BtnClose, Container } from "./style"

export interface IInput {
    type?: 'Location' | 'Raio' | 'Marca' | 'Modelo' | 'Ano' | 'Preco' | 'Versao'
    options?: object[]
    setValue?: (e:number) => void;
  }


export const Input = ({type,options,setValue}:IInput) => {
    const [location,setLocation] = useState('Todos')
    const [raio,setRaio] = useState('100Km')
    const [marca,setMarca] = useState('Todas')
    const [modelo,setModelo] = useState('Todos')
    const [ano,setAno] = useState('')
    const [preco,setPreco] = useState('Todos')
    const [versao,setVersao] = useState('Todas')


    if(type === 'Location'){
        return (
            <Container flex={2}>
                <IoLocationOutline  color="#f3123c"/> Onde: 
                <select id="Location" value={location} onChange={(e:any) => setLocation(e.target.value)}>
                    <option value='Todos'>Todos</option>
                    <option value='São Paulo - SP'>São Paulo - SP</option>
                    <option value='Aracaju - SE'>Aracaju - SE</option>
                    <option value='Maceió - AL'>Maceió - AL</option>
                </select>
                <BtnClose onClick={()=> setLocation('Todos')}>
                    <FaTimesCircle/>
                </BtnClose>
            </Container>
        )
    }
    else if(type === 'Raio'){
        return (
            <Container flex={1}>
                Raio: 
                <select id="Raio" value={raio} onChange={(e:any) => setRaio(e.target.value)}>
                    <option value='100km'>100km</option>
                    <option value='150km'>150km</option>
                    <option value='200km'>200km</option>
                </select>
                
            </Container>
        )
    }
    else if(type === 'Marca'){
        return (
            <Container flex={1}>
                Marca: 
                <select id="Marca" value={marca} onChange={(e:any) =>setValue?setValue(parseInt(e.target.value)):{}}>
                    <option value='Todas'>Todas</option>
                    {options?.map((op:any)=> (
                        <option key={op.ID} value={op.ID}>{op.Name}</option>
                    ))}
                </select>
            </Container>
        )
    }
    else if(type === 'Modelo'){
        return (
            <Container flex={1}>
                Modelo: 
                <select id="Modelo" value={modelo} onChange={(e:any) => setModelo(e.target.value)}>
                    <option value='Todos'>Todos</option>
                    {options?.map((op:any)=> (
                        <option key={op.ID} value={op.ID}>{op.Name}</option>
                    ))}
                </select>
            </Container>
        )
    }
    else if(type === 'Ano'){
        return (
            <Container flex={1}>
                <select id="Ano" value={ano} onChange={(e:any) => setAno(e.target.value)}>
                    <option value='Ano Desejado'>Ano Desejado</option>
                    <option value='2010'>2010</option>
                    <option value='2011'>2011</option>
                    <option value='2012'>2012</option>
                </select>
            </Container>
        )
    }
    else if(type === 'Preco'){
        return (
            <Container flex={1}>
                <select id="Preco" value={preco} onChange={(e:any) => setPreco(e.target.value)}>
                    <option value='Faixa de Preço'>Faixa de Preço</option>
                    <option value='R$ 5.000 - R$ 10.000,00'>R$ 5.000 - R$ 10.000,00</option>
                    <option value='R$ 10.000 - R$ 20.000,00'>R$ 10.000 - R$ 20.000,00</option>
                    <option value='R$ 20.000 - R$ 30.000,00'>R$ 20.000 - R$ 30.000,00</option>
                    <option value='R$ 30.000 - R$ 40.000,00'>R$ 30.000 - R$ 40.000,00</option>
                </select>
            </Container>
        )
    }
    else if(type === 'Versao'){
        return (
            <Container flex={2}>
                Versão: 
                <select id="Versao" value={versao} onChange={(e:any) => setVersao(e.target.value)}>
                    <option value='Todas'>Todas</option>
                    <option value='Aaaa'>Aaaa</option>
                    <option value='Bbbb'>Bbbb</option>
                </select>
            </Container>
        )
    }

    return (
        <Container>
           
        </Container>
    )
}