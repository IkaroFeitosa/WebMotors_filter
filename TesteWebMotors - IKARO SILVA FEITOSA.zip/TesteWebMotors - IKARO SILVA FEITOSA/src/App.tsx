
import { Layout } from './components/Layout';
import url from './assets/img/webmotors.svg';
import { Logo } from './components/Layout/style';
import { Menu } from './components/Menu';
import { Filter } from './components/Filter';

function App() {
  return (
    <Layout>
      <Logo src={url}/>
      <Menu />
      <Filter/>
    </Layout> 
  );
}

export default App;
