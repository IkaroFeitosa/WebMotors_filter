
import axios from 'axios'

const api = axios.create({
    baseURL: 'https://desafioonline.webmotors.com.br',
});

export const getMaker = async () => {
    const res = await api.get('/api/OnlineChallenge/Make')
    return res;
}
export const getModel = async (MakeID:number) => {
    const res = await api.get('/api/OnlineChallenge/Model',{ params: { MakeID } })
    return res;
}
